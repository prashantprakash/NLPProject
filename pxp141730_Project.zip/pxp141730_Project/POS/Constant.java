/*
 * @author : Prashant Prakash
 * @email_id : pxp141730@utdallas.edu
 * @cretaed_date : 26th Nov 2015
 * 
 */

public class Constant {
	public static final Integer ONE = 1;
	public static final String SPACES = " ";
	public static final double DOUBLEONE = 1.0;
	public static final String START = "<s>";
}
